package com.login.dao;

  
	public class User {  
	private int id;  
	private String date,Event,Contact,Organizer;  
	//generate getters and setters  
	
	public void setId(int int1) {
		// TODO Auto-generated method stub
		
	}
	public String getdate() {
		// TODO Auto-generated method stub
		return null;
	}
	public String getOrganizer() {
		// TODO Auto-generated method stub
		return null;
	}
	public String getEvent() {
		// TODO Auto-generated method stub
		return null;
	}
	public String getContact() {
		// TODO Auto-generated method stub
		return null;
	}
	public void setdate(String string) {
		// TODO Auto-generated method stub
		
	}
	public void setOrganizer(String string) {
		// TODO Auto-generated method stub
		
	}
	public void setEvent(String string) {
		// TODO Auto-generated method stub
		
	}
	public void setContact(String string) {
		// TODO Auto-generated method stub
		
	}
	public String getid() {
		// TODO Auto-generated method stub
		return null;
	}
	}  

